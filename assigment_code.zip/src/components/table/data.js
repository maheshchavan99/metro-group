export const tableheader=["Date","Title", "discription","Status","Actions"]
export const tableData=[
    {id:1,
        date:"2025-06-28",
        title:"maheshchavan",
        discription:"mahesh@gmail.com",
        status:"in Progress"
    },
    {id:2,
        date:"2025-06-28",
        title:"maheshchavan",
        discription:"mahesh@gmail.com",
        status:"Completed"
    },
    {id:3,
        date:"2025-06-28",
        title:"maheshchavan",
        discription:"mahesh@gmail.com",
        status:"To do"
    },
    {id:4,
        date:"2025-06-28",
        title:"maheshchavan",
        discription:"mahesh@gmail.com",
        status:"Testing"
    },
    {id:5,
        date:"2025-06-28",
        title:"maheshchavan",
        discription:"mahesh@gmail.com",
        status:"In Progress"
    },
    {id:6,
        date:"2025-06-28",
        title:"maheshchavan",
        discription:"mahesh@gmail.com",
        status:"Testing"
    },
    {id:7,
        date:"2025-06-28",
        title:"maheshchavan",
        discription:"mahesh@gmail.com",
        status:"Completed"
    },
]