
function Layout({children}) {
  return (
    <div style={{width:"100%",maxWidth:"1200px", margin:" 50px auto"}}>
      {children}
    </div>
  )
}

export default Layout
